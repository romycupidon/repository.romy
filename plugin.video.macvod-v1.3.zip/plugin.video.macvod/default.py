import os
import sys
try:
    from urllib.request import urlopen
    import urllib.request as urllib2
    from urllib.parse import urlparse
    import urllib.parse as urllib_
    import urllib.error
except:
    from urllib import urlopen    
    from urlparse import urlparse
    import urllib as urllib_
    import urllib2
import re
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import plugintools
import unicodedata
import requests
import shutil
import base64
import time
import random
from resources.modules import control

PY3=False
if sys.version_info[0] >= 3: PY3 = True; unicode = str; unichr = chr; long = int
addon = xbmcaddon.Addon()
addonname = '[LOWERCASE][CAPITALIZE][COLOR white]Mac[COLOR white]VOD[/CAPITALIZE][/LOWERCASE][/COLOR]'
icon = addon.getAddonInfo('icon')
myaddon = xbmcaddon.Addon("plugin.video.macvod")
#px={"http": "http://14.139.189.213:3128"}
px=''
local_file=xbmc.translatePath('special://home/addons/plugin.video.macvod/proxy.dat')

## Fotos
thmb_nada='https://static.thenounproject.com/png/409659-200.png'
thmb_ver_canales='https://i.ibb.co/7YzbSf0/live.jpg'
thmb_ver_vod='https://i.ibb.co/4S3L3CN/vodmac.jpg'
thmb_cambio_servidor='https://i.ibb.co/7G2dqYZ/server.jpg'
thmb_cambio_mac='https://i.ibb.co/ZxttPbc/mac.jpg'
thmb_carga_servidores='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRup-gZATZL0rtNpZkg8UiKuOM-DmEY4az5Xq8arVwVM9IHXARs_RDjOt-R3PgV37rN1ts&usqp=CAU'
thmb_guarda_servidores='https://upload.wikimedia.org/wikipedia/commons/thumb/9/92/Gnome-document-save.svg/1024px-Gnome-document-save.svg.png'
thmb_nuevo_servidor='https://icons.iconarchive.com/icons/custom-icon-design/pretty-office-9/256/new-file-icon.png'
thmb_guia='https://static.vecteezy.com/system/resources/previews/000/567/906/non_2x/vector-tv-icon.jpg'
fanny="https://i.ytimg.com/vi/_7bFXWNfXTY/maxresdefault.jpg"
fanart_guia="http://www.panoramaaudiovisual.com/wp-content/uploads/2012/01/EPG-Toshiba-Smart-Tv-web.png"
backgr="https://freeiptvstb.com/wp-content/uploads/2021/06/UZ4VHKEdhTkviRzJSEfFZC.jpg"
thmb_ver_set='https://i.ibb.co/ZYHQfmg/setting.jpg'
thmb_ver_xc='https://i.ibb.co/0MRwStV/xcodes.jpg'
thmb_ver_stb='https://i.ibb.co/H7RzfhF/maciptv.jpg'
thmb_ver_m3u='https://i.ibb.co/Zftwwc9/liveiptv.jpg'
thmb_about='https://i.ibb.co/kXDSdZN/about.jpg'

portal = control.setting('portal')
mac = control.setting('mac')
userp = control.setting('userp')
portalxc = control.setting('portalxc')
usernamexc = control.setting('usernamexc')
passxc = control.setting('passxc')

def run():
    #
    
    # Get params
           
    params = plugintools.get_params()
    
    if params.get("action") is None:
        if PY3==False:
            xbmc.executebuiltin('Container.SetViewMode(51)')        
        
        main_list(params)
    else:
       if PY3==False:
           xbmc.executebuiltin('Container.SetViewMode(51)') 
       action = params.get("action")
       url = params.get("url")
       exec (action+"(params)")

    plugintools.close_item_list()

def cambia_fondo():

    foto = xbmc.translatePath('special://home/addons/plugin.video.macvod/fondo.jpg')    
    if not xbmc.getCondVisibility('Skin.String(CustomBackgroundPath)'):      
        xbmc.executebuiltin('Skin.Reset(CustomBackgroundPath)')
        xbmc.executebuiltin('Skin.SetBool(UseCustomBackground,True)')   
        xbmc.executebuiltin('Skin.SetString(CustomBackgroundPath,'+foto+')')
        xbmc.executebuiltin('ReloadSkin()')
    
def main_list(params):
    proxy=params.get('extra')
    import shutil,xbmc  
    try:
        addon_path3 = xbmc.translatePath('special://home/cache').decode('utf-8')
        shutil.rmtree(addon_path3, ignore_errors=True) 
    except:
        pass
    
    cambia_fondo()
        
    plugintools.log("macvod.main_list ")    
    params['title']="[COLOR red]i[COLOR white]P[COLOR green]TV[COLOR white] CHaNNeLS[/COLOR]"
    params['thumbnail']=thmb_ver_canales
    params['fanart']="https://i.ytimg.com/vi/_7bFXWNfXTY/maxresdefault.jpg"
    mac=myaddon.getSetting('mac')
    portal=myaddon.getSetting('portal')
	
    plugintools.add_item(title='[COLOR gray]-======== SUPORT =========-[/COLOR]',folder=False, isPlayable=False)   
	
    plugintools.add_item(title='[COLOR blue]KodiRomania[/COLOR]',folder=False, isPlayable=False)
	
    plugintools.add_item(title='[COLOR blue]https://t.me/kodiromania[/COLOR]',folder=False, isPlayable=False)
		
    plugintools.add_item(title='[COLOR gray]-=========================-[/COLOR]',folder=False, isPlayable=False) 
	
    plugintools.add_item( action="mac", title="[COLOR white]STB / MAC[/COLOR]", thumbnail = thmb_ver_stb, fanart= backgr,page="",url="",folder=True )
		
    plugintools.add_item( action="ipkoditv_enigmax", title="[COLOR white]Xtream Codes[/COLOR]", thumbnail = thmb_ver_xc, fanart= backgr,page="",url="",folder=True )
	
    plugintools.add_item( action="m3u", title="[COLOR white]Liste M3U[/COLOR]", thumbnail = thmb_ver_m3u, fanart= backgr,page="",url="",folder=True )
	
    plugintools.add_item( action="settings", title="[COLOR white]Setari[/COLOR]", thumbnail = thmb_ver_set, fanart= backgr,page="",url="",folder=False )
   
    plugintools.add_item( action="", title="KodiRomania - https://t.me/kodiromania - Grup telegram", thumbnail = thmb_about, fanart= backgr,page="",url="",folder=False )

def settings(params): 
    plugintools.open_settings_dialog()
    xbmc.executebuiltin('Container.Refresh')
	

def mac(params):
    plugintools.add_item( action="macpastebinx", title="[COLOR white]STB / MAC Pastebin[/COLOR]", thumbnail = thmb_ver_stb, fanart= backgr,page="",url="",folder=True )
    plugintools.add_item( action="macx", title="[COLOR white]STB / MAC Personal[/COLOR]", thumbnail = thmb_ver_stb, fanart= backgr,page="",url="",folder=True )


def macpastebinx(params):
    if userp=="":
        userpast = userpastebin()
        control.setSetting('userp',userpast)
        xbmc.executebuiltin('Container.Refresh')
        cambio_servidor(params)
    else:
        macpastebin(params)
		
def userpastebin():
    kb = xbmc.Keyboard('', 'heading', True)
    kb.setHeading('CONT PASTEBIN')
    kb.setHiddenInput(False)
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText()
        return text
    else:
        return False
	


def macpastebin(params):
    import shutil,xbmc  
    try:
        addon_path3 = xbmc.translatePath('special://home/cache').decode('utf-8')
        shutil.rmtree(addon_path3, ignore_errors=True) 
    except:
        pass
    
    cambia_fondo()
        
    escogido=myaddon.getSetting('escogido')
    mac=myaddon.getSetting('mac2')
    


    plugintools.log("macvod.macpastebin")    
    plugintools.add_item(action="ver_canales",    title="LISTA CANALE IPTV",thumbnail=thmb_ver_canales,fanart="https://i.ytimg.com/vi/_7bFXWNfXTY/maxresdefault.jpg",folder= True )            
    plugintools.add_item(action="", thumbnail=thmb_nada,title="[COLOR gray]Configuratie actuala--------------------------------------------------------------------------[/COLOR]",folder= False )
    plugintools.add_item(action="cambio_servidor",    title="SERVER Actual:   "+escogido,thumbnail=thmb_cambio_servidor,fanart="https://www.zooplus.es/magazine/wp-content/uploads/2018/04/fotolia_169457098.jpg",folder= True )               
    plugintools.add_item(action="cambio_mac",         title="MAC Actual:   "+mac,thumbnail=thmb_cambio_mac,fanart="https://www.miwuki.com/wp-content/uploads/2016/11/gatito-830x623-300x225.jpg",folder= True )


def macx(params):
    if portal=="":
        portp = portpopup()
        macn = macpopup()
        control.setSetting('portal',portp)
        control.setSetting('mac',macn)
        xbmc.executebuiltin('Container.Refresh')
        mac2(params)
    else:
        mac2(params)
		
def macpopup():
    kb = xbmc.Keyboard('', 'heading', True)
    kb.setHeading('MAC')
    kb.setHiddenInput(False)
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText()
        return text
    else:
        return False

def portpopup():
    kb =xbmc.Keyboard ('', 'heading', True)
    kb.setHeading('PORTAL')
    kb.setHiddenInput(False)
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText()
        return text
    else:
        return False	

def mac2(params):
    plugintools.log("macovd.mac")    
    mac=myaddon.getSetting('mac')
    portal=myaddon.getSetting('portal')
	
    plugintools.add_item( action="tombola", title="[COLOR white]Canale live[/COLOR]", thumbnail = thmb_ver_canales, fanart= backgr,page=mac,url=portal,folder=True )
    
    plugintools.add_item( action="pelis", title="[COLOR white]VOD[/COLOR]", thumbnail = thmb_ver_vod, fanart= backgr,page=mac,url=portal,folder=True )


def tombola(params):
    import xbmc, time

    thumbnail = params.get("thumbnail") 
    portal = params.get("url")  
    mac = params.get("page")     
    s=''
    usuario = ''
    def macs(s):
        import requests,re
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain"}
        url=portal+'portal.php?type=stb&action=handshake&JsHttpRequest=1-xml'
        source=requests.get(url, headers=headers).text
 
        return source
    token =macs(s)
    token=re.findall('token":"(.*?)"',token)[0]
    token=str(token)    
    def macs(s):
        import requests,re    
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
        url=portal+'portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml'
        source=requests.get(url, headers=headers).text
        passs=re.findall('login":"","password":"(.*?)"',source )[0]
        typee=re.findall('"stb_type":"(.*?)"',source )[0]
        payload={"login":usuario,"password":passs,"stb_type":typee}
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
        url=portal+'portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml'
        s = requests.Session()
        source=s.post(url, headers=headers,data=str(payload)).text
        return source
    source=macs(s)
    data = plugintools.find_multiple_matches(source,'("id":"\d+.*?".*?"title":".*?",")')   
 
 
    for generos in data: 
        patron=plugintools.find_single_match(generos,'"id":"(\d+.*?)".*?"title":"(.*?)"') 
        titulo=patron[1]
        titulo=titulo.replace('\\u2b50','').replace('\\/','/')
        ids=patron[0]
        if  ('romania' in titulo.lower() or 'roumania' in titulo.lower() or 'EU- RO' in titulo):               
            color='lime'
            titulo='[LOWERCASE][CAPITALIZE][COLOR '+color+']'+titulo+'[/CAPITALIZE][/LOWERCASE][/COLOR]'           
        
        else:               
            color='white'
            titulo='[LOWERCASE][CAPITALIZE][COLOR '+color+']'+titulo+'[/CAPITALIZE][/LOWERCASE][/COLOR]'             

        if  ('adultxxxxxxxxx' in titulo.lower()):                        
                 
             titulo=' [LOWERCASE][CAPITALIZE][COLOR fuchsia]'+patron[1]+' seccion x[/CAPITALIZE][/LOWERCASE][/COLOR]'
             dialog = xbmcgui.Dialog()
             ret = dialog.select('[COLOR yellow]CONTIENE CANALES ADULTOS NECESITA CLAVE,¿QUE QUIERES?:[/COLOR]', ['[COLOR lime]METER LA CLAVE Y DISFRUTAR DE ELLOS[/COLOR]', '[COLOR aqua]NO QUIERO  LOS CANALES ADULTOS[/COLOR]'])
             lists = ['si', 'no']
             eleccion = lists[ret]
             if 'no' in eleccion:                 
                           
                 ids='99999999999'  
             if 'si' in eleccion:
                 dialog = xbmcgui.Dialog()
                 d = dialog.input('[B][LOWERCASE][CAPITALIZE][COLOR orange]meter la clave: [COLOR white]si no la tienes pideta en telegram @tvchopo[/COLOR][/CAPITALIZE][/LOWERCASE][/B]', type=xbmcgui.INPUT_ALPHANUM).replace(" ", "+")
                 if 'x69' in d:
                     ids=ids
                 else:
                     xbmcgui.Dialog().ok('[COLOR white]LA CLAVE ES INCORRECTA[/COLOR]', '[LOWERCASE][CAPITALIZE][COLOR white]METE LA CLAVE EN MINUSCULA\nSI NO LO CONSIGUES ESTAMOS EN TELEGRAM [COLOR white]@TVCHOPO[/COLOR][/CAPITALIZE][/LOWERCASE]')  
        plugintools.add_item( action="lista2", title="[COLOR white]"+titulo+"[/COLOR]", thumbnail = params.get("thumbnail"), fanart= params.get("thumbnail"),plot=token,page=mac,extra=portal,url=ids,folder=True )


def lista2(params):
    s=''
    ids = params.get("url")
    portal = params.get("extra")
    mac = params.get("page")
    token = params.get("plot")
    headers = '{"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="'+mac+'"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "'+token+'}'
    def macs(s):
       
        count=40;pn=1;data=[]
        while pn <= int(count):
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
            page=portal+'portal.php?type=itv&action=get_ordered_list&genre='+ids+'&force_ch_link_check=&fav=0&sortby=number&hd=0&p='+str(pn)+'&JsHttpRequest=1-xml';source=requests.get(page, headers=headers).text
            data +=re.findall('("id":".*?","name":".*?".*?"ch_id":".*?")',source);pn +=1
        return data
    
    url=macs(s)
    for generos in url: 
        patron = plugintools.find_single_match(generos,'"id":".*?","name":"(.*?)".*?"ch_id":"(.*?)"')
        canal=patron[1]
        titulo=patron[0]
        titulo=titulo.replace('\\u2b50','').replace('\\/','/')
        plugintools.add_item( action="lista3",extra=portal,url=canal,page=mac,plot=params.get("plot"),title="[LOWERCASE][CAPITALIZE][COLOR white]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]", thumbnail = params.get("thumbnail"), fanart= params.get("thumbnail"),folder=False,  isPlayable = True ) 
  
def lista3(params):
    s=''
    canal = params.get("url")
    portal = params.get("extra")
    mac = params.get("page")
    titulo1 = params.get("plot")
    def macs(s):
        import requests,re  
        headers =headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+titulo1}
        url=portal+'portal.php?type=itv&action=create_link&cmd=http://localhost/ch/'+canal+'_&series=&forced_storage=undefined&disable_ad=0&download=0&JsHttpRequest=1-xml'
        source=requests.get(url, headers=headers).text

        token=re.findall('"cmd":"ffmpeg (.*?)"',source )[0]
        source= token.replace("\\", "")
        return source
    url=macs(s)
    url=url
    plugintools.play_resolved_url(url)


def pelis(params):
    import xbmc, time
    portal = params.get("url")
    mac = params.get("page")
    s=''
    usuario = ''
    def macs(s):
        import requests,re
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain"}
        url=portal+'portal.php?type=stb&action=handshake&JsHttpRequest=1-xml'
        source=requests.get(url, headers=headers).text
 
        return source
    token =macs(s)
    token=re.findall('token":"(.*?)"',token)[0]
    token=str(token)    
    def macs(s):
        import requests,re    
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
        url=portal+'portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml'
        source=requests.get(url, headers=headers).text
        passs=re.findall('login":"","password":"(.*?)"',source )[0]
        typee=re.findall('"stb_type":"(.*?)"',source )[0]
        payload={"login":usuario,"password":passs,"stb_type":typee}
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
        url=portal+'portal.php?type=vod&action=get_categories&JsHttpRequest=1-xml'
        s = requests.Session()
        source=s.post(url, headers=headers,data=str(payload)).text
        return source
    source=macs(s)
    data = plugintools.find_multiple_matches(source,'("id":"\d+.*?".*?"title":".*?",")')   
 
 
    for generos in data: 
        patron=plugintools.find_single_match(generos,'"id":"(\d+.*?)".*?"title":"(.*?)"') 
        titulo=patron[1]
        titulo=titulo.replace('\\u2b50','')
        ids=patron[0]

        plugintools.add_item( action="pelis2", title="[COLOR white]"+titulo+"[/COLOR]", thumbnail = params.get("thumbnail"), fanart= params.get("thumbnail"),plot=token,page=mac,extra=portal,url=ids,folder=True )
def pelis2(params):
    s=''
    ids = params.get("url")
    portal = params.get("extra")
    mac = params.get("page")
    token = params.get("plot")
    headers = '{"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="'+mac+'"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "'+token+'}'
    def macs(s):
 
        count=40;pn=1;data=[]
        while pn <= int(count):
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
            page=portal+'portal.php?type=vod&action=get_ordered_list&genre='+ids+'&force_ch_link_check=&fav=0&sortby=number&hd=0&p='+str(pn)+'&JsHttpRequest=1-xml';source=requests.get(page, headers=headers).content.decode('ascii','ignore')
            data +=re.findall('("id":".*?".*?,"name":".*?".*?.*?"description":".*?".*?"year":".*?".*?screenshot_uri":".*?".*?_str":".*?","cmd":".*?")',source);pn +=1
        return data
    
    url=macs(s)
    for generos in url: 
        patron = plugintools.find_single_match(generos,'"id":".*?".*?,"name":"(.*?)".*?.*?"description":"(.*?)".*?"year":"(.*?)".*?screenshot_uri":"(.*?)".*?_str":"(.*?)","cmd":"(.*?)"')
        foto=patron[3].replace("\\", "")
        titulo=patron[0].replace("\\u00f1", "n")
        titulo=titulo.replace('\\/','').replace('\u2b50','')
        texto=patron[1]
        year=patron[2].replace('N\\/A','')
        canal=patron[5]
        plugintools.add_item( action="pelis3",extra=portal,url=canal,page=mac,plot=params.get("plot"),title="[LOWERCASE][CAPITALIZE][COLOR white]"+titulo+" [COLOR yellow]"+year+"[/CAPITALIZE][/LOWERCASE][/COLOR]", thumbnail = foto, fanart= foto,folder=False,  isPlayable = True ) 
  
def pelis3(params):
    s=''
    canal = params.get("url")
    portal = params.get("extra")
    mac = params.get("page")

    def macs(s):
        import requests,re  
        headers =headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+params.get("plot")}
        url=portal+'portal.php?type=vod&action=create_link&cmd='+canal+'_&forced_storage=undefined&disable_ad=0&download=0&JsHttpRequest=1-xml'
        source=requests.get(url, headers=headers).text
        token=re.findall('"cmd":"ffmpeg (.*?)"',source )[0]
        source= token.replace("\\", "")
        return source
    url=macs(s)
    url=url
    plugintools.play_resolved_url(url)
	
# code xtream
# code xtream
# code xtream

def ipkoditv_enigmax(params):
    if portalxc=="":
        pxc = portalxtream()
        uxc = userxtream()
        passxc = passxtream()
        control.setSetting('portalxc',pxc)
        control.setSetting('usernamexc',uxc)
        control.setSetting('passxc',passxc)
        xbmc.executebuiltin('Container.Refresh')
        ipkoditv_enigma(params)
    else:
        ipkoditv_enigma(params)
		
def portalxtream():
    kb = xbmc.Keyboard('', 'heading', True)
    kb.setHeading('PORTAL XTREAM CODES')
    kb.setHiddenInput(False)
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText()
        return text
    else:
        return False

def userxtream():
    kb = xbmc.Keyboard('', 'heading', True)
    kb.setHeading('USERNAME')
    kb.setHiddenInput(False)
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText()
        return text
    else:
        return False
		
def passxtream():
    kb = xbmc.Keyboard('', 'heading', True)
    kb.setHeading('PASSWORD')
    kb.setHiddenInput(False)
    kb.doModal()
    if kb.isConfirmed():
        text = kb.getText()
        return text
    else:
        return False

def ipkoditv_enigma(params): 
    plugintools.log("koditv.ipkoditv")
    thumbnail = params.get("thumbnail")    
    url1=myaddon.getSetting('portalxc')
    username=myaddon.getSetting('usernamexc')
    password=myaddon.getSetting('passxc')   
    url3 = url1+'/enigma2.php?username='+username+'&password='+password
    page='&type=get_live_categories'
    url=url3+page
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = plugintools.find_multiple_matches(url,'((?s)<title>.*?</title>.*?<description.*?>.*?<.*?CDATA.*?&cat_id=.*?>.*?)')
    for generos in matches:

        url=plugintools.find_single_match(generos,'(&cat_id=.*?)..>.*?')
        description=plugintools.find_single_match(generos,'<description.*?>(.*?)<.*?')
        
        import base64

        description= base64.b64decode(description)
        description = description.decode('utf-8')
        titulo=plugintools.find_single_match(generos,'<title>(.*?)</title>')

        message_bytes = base64.b64decode(titulo)
        titulo = message_bytes.decode('utf-8')
        url=url3+'&type=get_live_streams'+url
        
        
        plugintools.add_item(action="ipkoditv_enigma2", url=url,title="[LOWERCASE][CAPITALIZE][COLOR white]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=True )

def ipkoditv_enigma2(params): 
    plugintools.log("koditv.ipkoditv")
    thumbnail = params.get("thumbnail")    

    url3 = params.get("url")
    
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url3, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = plugintools.find_multiple_matches(url,'((?s)<title>.*?</title>.*?<description.*?>.*?<.*?CDATA..*?..>.*?DATA.*?http.*?.ts)')
    for generos in matches:

        patron=plugintools.find_single_match(generos,'(?s)<title>(.*?)</title>.*?<description.*?>(.*?)<.*?CDATA.(.*?)..>.*?DATA.*?(http.*?.ts)')
       
        url=patron[3]

        titulo=patron[0]
        import base64
        message_bytes = base64.b64decode(titulo)
        titulo = message_bytes.decode('utf-8')

        
        hora = plugintools.find_single_match(titulo,'\[(.*?)\]')
        emision = plugintools.find_single_match(titulo,'(?s) .*?[A-Z].*?[A-Z].*? \[.*?\] ....*?min   (.*)').replace('(','').replace('[','').replace('|','').replace(',','').replace('-','').replace('Live Streams','')
        titulo = plugintools.find_single_match(titulo,'(.*?[A-zZ]: .*?\[|.*?[A-zZ] .*?\[|.*?[A-zZ]: .*?\(|.*?[A-zZ]: .*? .*? |.*?[A-zZ]: [A-zZ].*|.*?[A-Z].*)').replace('(','').replace('[','').replace('|','').replace(',','').replace('-','').replace('Live Streams','')
        
        description=patron[1]
        data=patron[2]
        url = url
        
        plugintools.add_item(action="linkdirecto", url=url,title="[LOWERCASE][CAPITALIZE][COLOR white]"+titulo+" [COLOR white]" +hora+" [COLOR lime]"+emision+"[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=False,  isPlayable = True)
  
		
		
def linkdirecto(params):
    url = params.get("url")    
    plugintools.play_resolved_url(url)   
	
# code m3u
# code m3u
# code m3u	
def m3u(params):
    plugintools.log("macovd.m3u")    
    mac=myaddon.getSetting('mac')
    portal=myaddon.getSetting('portal')
    listam3u=myaddon.getSetting('listam3u')
	
    plugintools.add_item( action="listam3u1", title="[B][COLOR yellow]Lista mea M3U[/COLOR][/B]", thumbnail = thmb_ver_m3u, fanart= backgr,page="",url=listam3u,folder=True )
    plugintools.add_item( action="multilistas", title="Liste Romania",thumbnail="http://www.codrosu.ro/wp-content/uploads/2009/11/steagul-Romaniei.png", fanart="https://previews.123rf.com/images/reamolko/reamolko1605/reamolko160500022/56476783-espa%C3%B1a-pinceladas-de-colores-pinta-icono-nacional-de-bandera-de-pa%C3%ADs-textura-pintada-.jpg",page="",url= "https://www.gratisiptv.com/lists-iptv/",folder= True )
    plugintools.add_item( action="multilistas_mundo", title="Liste pe tari",thumbnail="http://4.bp.blogspot.com/_NNeaZcy4AMo/TN2rhImSCgI/AAAAAAAAAAU/1NciK750JOg/s1600/earth.png", fanart="https://www.gndiario.com/sites/default/files/styles/noticia_detalle_noticia_2_1/public/noticias/paz-mundial.jpg?h=f27025cf&itok=tfCe8KKi",page="",url= "https://www.gratisiptv.com/lists-iptv/",folder=True ) 	
    plugintools.add_item( action="mundotv", title="GitHub IPTV lists", thumbnail = thmb_ver_m3u, fanart= backgr,page="",url="https://github.com/bitsbb01/ez-iptvcat-scraper2/tree/main/data/countries",folder=True )
    plugintools.add_item( action="super_iptv", title="Liste XC World",thumbnail="https://i.pinimg.com/originals/10/11/2a/10112a78cc46fd641966b186deaced98.jpg", fanart="https://i.pinimg.com/originals/62/01/93/620193dbfc63e3510093489aaa8fb37a.jpg",page="",url= "https://usalinksiptv.blogspot.com",folder= True )
    plugintools.add_item( action="super_iptv2", title="Liste XC World2",thumbnail="https://i.pinimg.com/originals/10/11/2a/10112a78cc46fd641966b186deaced98.jpg", fanart="https://i.pinimg.com/originals/62/01/93/620193dbfc63e3510093489aaa8fb37a.jpg",page="",url= "https://telegra.ph/IPTV-playlist-m3u-daily-update-10-31",folder= True )
    plugintools.add_item( action="listam3u1", title="[COLOR white]M3U List 1[/COLOR]", thumbnail = thmb_ver_m3u, fanart= backgr,page="",url="https://raw.githubusercontent.com/ParrotDevelopers/Parrot-TV-M3U/main/Assets/Channels/RO%20Channels.m3u",folder=True )

def mundotv(params): 
    plugintools.log("macvod.mundotv")
    thumbnail = params.get("thumbnail")    
    url3 = params.get("url")    
    s = ''
    def macs(s):
        import requests,re
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0"}
        url=url3
        source=requests.get(url, headers=headers).text
        token=re.findall('(title=".*?.json" data-pjax="#repo-content-pjax-container" href="/bitsbb01/ez-iptvcat-scraper2/blob/main/data/countries/.*?")',source ) 
        return token
    url =macs(s)
    for generos in url:
        title=plugintools.find_single_match(generos,'title="(.*?).json') 
        url='https://raw.githubusercontent.com/bitsbb01/ez-iptvcat-scraper2/main/data/countries/'+plugintools.find_single_match(generos,'href=".*?blob/main/data/countries/.*?(.*?)"')
        plugintools.add_item(action="mundotv2", url=url,title="[LOWERCASE][CAPITALIZE][COLOR white]"+str(title)+"[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=True )

def mundotv2(params): 
    plugintools.log("macvod.mundotv")
    thumbnail = params.get("thumbnail")    
    url3 = params.get("url")    
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url3, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = plugintools.find_multiple_matches(url,'("id.+?lastChecked")')

    for generos in matches:
        title=plugintools.find_single_match(generos,'"channel": "(.*?)"') 
        url=plugintools.find_single_match(generos,'link": "(.*?)"') 
        status=plugintools.find_single_match(generos,'status": "(.*?)"') 
        if 'online'in status:
            status='[COLOR lime]'+status
        else:
            status='[COLOR red]'+status
        plugintools.add_item(action="linkdirecto", url=url,title="[LOWERCASE][CAPITALIZE][COLOR white]"+title+" " +status+"[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=False,  isPlayable = True)


def multilistas_mundo(params): 
    plugintools.log("macvod.multilistas_mundo")
    thumbnail = params.get("thumbnail")    
    plugintools.add_item(action="", title="[COLOR yellow]===[LOWERCASE][CAPITALIZE][COLOR aquamarine]multilistas mundo [COLOR yellow]===[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail="https://www.montero-aramburu.com/wp-content/uploads/2017/07/deportes_varios.jpg", fanart="https://www.radiomarcalanzarote.com/images/2019/10/1agenda-deportiva-del-fin-de-semana.jpg",  url= "http://www.formulatv.com/programacion/",folder= False ) 
    
    url = params.get("url")
    
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = plugintools.find_multiple_matches(url,'((?s)menu-item-has-children menu-item-.*?<a href=".*?">.*?<.*?|item-object-category menu-item-.*?href=".*?">.*?<)')
    for generos in matches:
        pais=plugintools.find_single_match(generos,'tem-has-children menu-item-.*?<a href=".*?">(.*?)<.*?|item-object-category menu-item-.*?href=".*?">.*?<')
        url=plugintools.find_single_match(generos,'item-object-category menu-item-.*?href="(.*?)"')
        titulo=plugintools.find_single_match(generos,'(?s)menu-item-has-children menu-item-.*?<a href=".*?">.*?<.*?|item-object-category menu-item-.*?href=".*?">(.*?)<')
        request_headers=[]
        request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
        body,response_headers = plugintools.read_body_and_headers( url, headers=request_headers)
        url = body.strip().decode('utf-8')
        url=plugintools.find_single_match(url,'(?s)archive-title">Category.*? itemprop="headline"><a href="(.*?)"')        
        plugintools . add_item ( action = "multilistas_mundo2" , title = "[LOWERCASE][CAPITALIZE][COLOR lime]"+pais+" [COLOR white]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]", url = url, thumbnail =  thumbnail , fanart=thumbnail, folder=True)
        
        
    plugintools.add_item(action="", title="[COLOR yellow]===[LOWERCASE][CAPITALIZE][COLOR aquamarine]multilistas mundo [COLOR yellow]===[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail="https://www.montero-aramburu.com/wp-content/uploads/2017/07/deportes_varios.jpg", fanart="https://www.radiomarcalanzarote.com/images/2019/10/1agenda-deportiva-del-fin-de-semana.jpg",  url= "http://www.formulatv.com/programacion/",folder= False ) 


def multilistas_mundo2(params): 
    plugintools.log("macvod.multilistas_mundo")
    thumbnail = params.get("thumbnail")    

       
    url = params.get("url")
    
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = plugintools.find_multiple_matches(url,'(<a href="https://gratisiptv.com/m3u/.*?">Download .*? IpTV .*?</a>)')
    for generos in matches:

        patron=plugintools.find_single_match(generos,'<a href="(https://gratisiptv.com/m3u/.*?)">Download .*? IpTV (.*?)</a>')
        url=patron[0]
        titulo=patron[1] 
        plugintools . add_item ( action = "multilistas2" , title = "[LOWERCASE][CAPITALIZE] [COLOR white]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]", url = url, thumbnail =  thumbnail , fanart=thumbnail, folder=True )
        

def multilistas(params): 
    plugintools.log("macvod.adictos ")
    thumbnail = params.get("thumbnail")    
    url = params.get("url")    
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url, headers=request_headers)
    url = body.strip().decode('utf-8')
    url = plugintools.find_single_match(url,'category menu-item-424"><a href="(https://www.gratisiptv.com/.*?roma.*?)">Romanian')    
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url, headers=request_headers)
    url = body.strip().decode('utf-8')
    url = plugintools.find_single_match(url,'(?s)Category: Romanian.*?itemprop="headline"><a href="(.*?)">')
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = plugintools.find_multiple_matches(url,'((?s)<a href="https://gratisiptv.com/m3u/.*?">Download Romania IpTV .*?<)')
    for generos in matches:
        matches = plugintools.find_single_match(generos,'(?s)<a href="(https://gratisiptv.com/m3u/.*?)">Download Romania IpTV (.*?)<')
        url = matches[0]
        titulo = matches[1]
        plugintools . add_item ( action = "multilistas2" , title = "[LOWERCASE][CAPITALIZE][COLOR gold]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]", url = url, thumbnail =  thumbnail , fanart=thumbnail, folder=True )
   

def multilistas2(params): 
    plugintools.log("macvod.multilistas2")
    thumbnail = params.get("thumbnail")    
    url3 = params.get("url")
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url3, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = plugintools.find_multiple_matches(url,'((?i)EXTINF:....*?.*?http.*?#)')

    for generos in matches:
        matches = plugintools.find_single_match(generos,'(?i)EXTINF:....*?(.*?)(http.*?)\s*#')
        url = matches[1]
        titulo = matches[0].replace('|','').replace(',','').replace('-','')    
        server = plugintools.find_single_match(url,'http://(.*?):.*?/')
        import socket
        equipo_remoto = server
        servidor= socket.gethostbyname(equipo_remoto) 
        url=url.replace(server,servidor)     
        plugintools.add_item(action="linkdirecto", url=url,title="[LOWERCASE][CAPITALIZE][COLOR white]"+titulo+"[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=False,  isPlayable = True )

def super_iptv(params): 
    plugintools.log("koditv.super_iptv")
    thumbnail = params.get("thumbnail")           
    url = params.get("url") 
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = plugintools.find_multiple_matches(url,'(post-body entry-content.*?Older Posts)')
    for generos in matches:    
        matches = plugintools.find_multiple_matches(generos,'(http://.*?/get.php.username=.*?&.*?password=.*?&.*?<br)')
        for generos in matches:
            patron=plugintools.find_single_match(generos,'(?s)http://(.*?)/get.php.username=(.*?)&.*?password=(.*?)&.*?<br')
            url1=patron[0]
            servidores = plugintools.find_single_match(url1,'(.*?):')
            try:
                import socket
                equipo_remoto = servidores
                servidor= socket.gethostbyname(equipo_remoto) 
                url1=url1.replace(servidores,servidor)
            except:
                pass
            username=patron[1]
            password=patron[2]
            url='http://'+url1+'/enigma2.php?username='+username+'&password='+password
        
        
            plugintools.add_item(action="super_iptv_enigma", url=url,title="[LOWERCASE][CAPITALIZE][COLOR white]"+servidores+"[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=True )    


def super_iptv2(params): 
    plugintools.log("koditv.super_iptv2")
    thumbnail = params.get("thumbnail")           
    url = params.get("url") 
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = plugintools.find_multiple_matches(url,'(<article.*?</article>)')
    for generos in matches:    
        matches = plugintools.find_multiple_matches(generos,'(http\:/\\/.+?\/get.php\?username=.+?\&amp\;password=.+?\&amp\;)')
        for generos in matches:
            patron=plugintools.find_single_match(generos,'(?s)(http\:\/\/.+?\/)get.php\?username=(.+?)\&amp\;password=(.+?)\&amp\;')
            url1=patron[0]
            servidores = plugintools.find_single_match(url1,'\/\/(.*?)\/')
            try:
                import socket
                equipo_remoto = servidores
                servidor= socket.gethostbyname(equipo_remoto) 
                url1=url1.replace(servidores,servidor)
            except:
                pass
            username=patron[1]
            password=patron[2]
            url=url1+'enigma2.php?username='+username+'&password='+password
        
        
            plugintools.add_item(action="super_iptv_enigma", url=url,title="[LOWERCASE][CAPITALIZE][COLOR white]"+servidores+"[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=True )    



def super_iptv_enigma(params): 
    plugintools.log("koditv.ipkoditv")
    thumbnail = params.get("thumbnail")    
   
    url3 = params.get("url")
    page='&type=get_live_categories'
    url=url3+page
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url, headers=request_headers)
    url = body.strip().decode('utf-8')
    matches = plugintools.find_multiple_matches(url,'((?s)<title>.*?</title>.*?<description.*?>.*?<.*?CDATA.*?&cat_id=.*?>.*?)')
    for generos in matches:

        url=plugintools.find_single_match(generos,'(&cat_id=.*?)..>.*?')
        description=plugintools.find_single_match(generos,'<description.*?>(.*?)<.*?')
        
        import base64

        description= base64.b64decode(description)
        description = description.decode('utf-8')
        titulo=plugintools.find_single_match(generos,'<title>(.*?)</title>')

        message_bytes = base64.b64decode(titulo)
        titulo = message_bytes.decode('utf-8')
        url=url3+'&type=get_live_streams'+url
        
        
        plugintools.add_item(action="ipkoditv_enigma2", url=url,title="[LOWERCASE][CAPITALIZE][COLOR white]"+titulo+" "+description+"[/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=True )


def listam3u1(params): 
    plugintools.log("macvod.listam3u1")
    thumbnail = params.get("thumbnail")    

    
    url3 = params.get("url")
 
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    body,response_headers = plugintools.read_body_and_headers( url3, headers=request_headers)
    url = body.strip().decode('utf-8')

    matches = plugintools.find_multiple_matches(url,'(#EXTINF:.+?,.*?[\n\r]+[^\n]+)')
    for generos in matches:  
        patron=plugintools.find_single_match(generos,'(?s)#EXTINF:.+?,(.*?)[\n\r]+([^\n]+)')    
        url=patron[1]
        titulo=patron[0]     
     
        plugintools.add_item(action="radio_play", url=url,title="[LOWERCASE][CAPITALIZE][COLOR white]"+titulo+" [/CAPITALIZE][/LOWERCASE][/COLOR]",thumbnail=thumbnail,fanart=thumbnail,folder=False,  isPlayable = True )


def radio_play(params):            
    url = params.get("url")
    try:
        plugintools.play_resolved_url( url )    
    except:
        pass

#code macpastebin
#code macpastebin


def ver_canales(params):
      
    thumbnail = params.get("thumbnail")
    
    mac=myaddon.getSetting('mac2')
    portal=myaddon.getSetting('portal2')
    escogido=myaddon.getSetting('escogido')
    s=''
    usuario = ''
  
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain"}
    url=portal+'portal.php?type=stb&action=handshake&JsHttpRequest=1-xml'
        
    source=''
    
    try:
        source = requests.Session()
        source=requests.get(url, headers=headers).content
    except:
    
        xbmc.executebuiltin('XBMC.Notification( Nu se poate conecta la SERVER: ' + escogido +', '+portal+' '+mac+ ', 8000)')            
    
    if source =='':
        xbmc.executebuiltin('XBMC.Notification( Nu se poate conecta la SERVER: ' + escogido +', '+str(source)+ ', 8000)')  
        #xbmc.log('ERROR conectando al servidor: '+str(source)+' : '+str(url))
        #xbmc.executebuiltin('Action(Back)')
        #return(params)
    
    token=''
    try:
        token=re.findall('token":"(.*?)"', str(source) )[0] 
    except:       
        xbmc.executebuiltin('XBMC.Notification( Nu se poate conecta la SERVER: ' + escogido +', '+str(source)+ ', 8000)')  
        #xbmc.executebuiltin('Action(Back)')
        #return(params)
    
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+str(mac)+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
    url=portal+'portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml'
    source=""
    
    usuario=''
    
    source = requests.Session()           
    source=requests.get(url, headers=headers).content
    
    try:
        passs=re.findall('login":"","password":"(.*?)"',source )[0]
        typee=re.findall('"stb_type":"(.*?)"',str(source) )[0]
    except:
        passs=''
        usuario=''
        typee=''
            
    payload={"login":usuario,"password":passs,"stb_type":typee}
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
    url=portal+'portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml'
        
    source=''
    
    s = requests.Session()                
    source=s.post(url, headers=headers,data=str(payload)).text
    
    if source!='':
        
        data = plugintools.find_multiple_matches(source,'("id":"\d+.*?".*?"title":".*?",")')   
        pr0n=myaddon.getSetting('pr0n')  
        plugintools.add_item(title='[COLOR gray]-=========================-[/COLOR]',folder=False, isPlayable=False)   
        plugintools.add_item(title='[COLOR blue]ACTUAL [ '+escogido+' # '+mac+' ][/COLOR]',folder=False, isPlayable=False)
        plugintools.add_item(title='[COLOR gray]-=========================-[/COLOR]',folder=False, isPlayable=False) 
        for generos in data: 
            
            patron=plugintools.find_single_match(generos,'"id":"(\d+.*?)".*?"title":"(.*?)"') 
            titulo=patron[1]
            ids=patron[0]
                        
            tit=colorea(titulo)
            
            if  not('adult' in titulo.lower() and pr0n=="false"):                            
                #plugintools.add_item(action="paginar_canales", title=tit, thumbnail = params.get("thumbnail"), fanart= params.get("thumbnail"),plot=token,page=mac,extra=portal,url=ids,folder=True)                         
                plugintools.add_item(action="todos_los_canales", title=tit, thumbnail = params.get("thumbnail"), fanart= params.get("thumbnail"),plot=token,page=mac,extra=portal,url=ids,folder=True)
    else:
        xbmc.executebuiltin('XBMC.Notification([COLOR red]Problema '+'[COLOR white]'+escogido+'[/COLOR],[COLOR white]'+portal+' '+mac+'[/COLOR], 10000)')            
        
def cambio_servidor(params):

    server2=myaddon.getSetting('ser')
    escogido=myaddon.getSetting('escogido')
    userp=myaddon.getSetting('userp')
    portal= myaddon.getSetting('portal2')
    mac= myaddon.getSetting('mac2')
    dialog = xbmcgui.Dialog()
    
    
    #lists=myaddon.getSetting('lista').split(',')
    #lista_servidores=myaddon.getSetting('lista_servidores').split(',')
    listaservere = urllib.request.urlopen(urllib.request.Request("https://pastebin.com/u/"+userp)).read().decode('utf-8')
    lists = re.findall('(?s)data-key=".+?".+?href="/(.+?)".+?</div', listaservere) 
    #lists=lista
    lista_servidores= re.findall('(?s)data-key=".+?".+?href=".+?">(.+?)<.+?</div', listaservere)
	
	
    retorno = dialog.select('[COLOR blue]Server ACTUAL: [/COLOR]'+str(escogido), lista_servidores)

        
        #if retorno<>-1:
        #xbmc.executebuiltin('XBMC.Notification(Lista,'+lista_servidores[retorno]+',8000)')
        
    dialog = xbmcgui.Dialog()    
        
    if str(retorno)!='-1':   
        server2=lists[retorno]
        escogido=lista_servidores[retorno]
        if 1==1: #try:     
            
            mac1 = str(urllib2.urlopen(urllib2.Request("https://pastebin.com/raw/"+server2)).read())
            
            mac=""
            mac=re.findall('(00:.*?79:.*?........)', mac1)            
            portal=re.findall('portal"(.*?)"', mac1.lower())[0]
            maclista=''
            random.seed()
            
            while maclista == '' or not maclista:
                maclista = random.choice(mac)
        
            mac=maclista                
            myaddon.setSetting('mac2',mac)
            myaddon.setSetting('portal2',portal)
            myaddon.setSetting('ser',server2)
            myaddon.setSetting('escogido',escogido)
        else:
        #except:
            xbmc.executebuiltin('XBMC.Notification( Eroare la deschiderea: ' + str(escogido) +', '+str(portal)+' '+str(mac)+ ', 8000)')               
            xbmc.executebuiltin('Action(Back)')        
    else:
        xbmc.executebuiltin('Action(Back)')        

    xbmc.executebuiltin('Content.refresh')
    ver_canales(params)        


def cambio_mac(params):
       
    try:
        server2 = myaddon.getSetting('ser')
        macant= myaddon.getSetting('mac2')
        escogido= myaddon.getSetting('escogido')
    except:
        server2='pfducjrm'
    if escogido=='Fisier_LOCAL':
        xbmc.executebuiltin('XBMC.Notification(Fisier local, Fisierul LOCAL functioneaza cu un singur MAC. Daca doresti sa schimbi MAC-ul adauga o noua linie in fisierul local. , 8000)')                        
        xbmc.executebuiltin('Content.Refresh')
        xbmc.executebuiltin('Action(Back)')
    
    else:

        try:    
            mac1 = str(urllib2.urlopen(urllib2.Request("https://pastebin.com/raw/"+server2)).read())
            mac=""
            mac=re.findall('(00:.*?79:.*?........)', mac1)
            portal=re.findall('portal"(.*?)"', mac1.lower())[0]
            dialog = xbmcgui.Dialog()
            ret = dialog.select('MAC ACTUAL: [ '+str(escogido)+' # '+str(macant)+' ]', ['Schimba MAC', 'Continua cu MAC '+macant])
            lists = ['si','no']
    
            categorias= lists[ret]
                
            if 'si' in categorias:
                newmac=''
            
                selectable="Alege un MAC Random"
                for mc in mac:                                    
                        selectable=selectable+','+str(mc)
                
                lista_macs=selectable.split(",")
                ret=dialog.select('Alege un MAC:',lista_macs)

                if ret==1:
                    random.seed()
                    while newmac == '' or not newmac:
                        newmac = random.choice(mac)                      
                else:
                    if ret==-1:
                        newmac=macant
                    else:
                        newmac=mac[ret-1]

                if newmac!=macant:
                        myaddon.setSetting('mac2',newmac)
                        xbmc.executebuiltin('XBMC.Notification( MAC nou, ' +newmac+ ', 8000)')                        
    
        except:
                xbmc.executebuiltin('XBMC.Notification( Eroare MAC nou, Se continua cu' +macant+ ', 8000)')    
                xbmc.executebuiltin('Action(Back)')        

        xbmc.executebuiltin('Content.refresh')
        ver_canales(params)

    
def todos_los_canales(params):

    vpagina = params.get("thumbnail")
    ids = params.get("url")
    portal = params.get("extra")
    mac = params.get("page")
    token = params.get("plot")
    
    guardar_favs=myaddon.getSetting('favs')
    favoritos = xbmc.translatePath('special://home/userdata/favourites.xml')
    if guardar_favs=="true":
        try:
            f = open(favoritos,'r');favs = f.read();f.close()
        except:
            f = open(favoritos,'w+');f.write('</favourites>');f.close()
   
    pr0n=myaddon.getSetting('pr0n')
    plugintools.add_item(title='[COLOR gray]-=========================-[/COLOR]',folder=False, isPlayable=False)   
    plugintools.add_item(title='[COLOR blue]ACTUAL [ '+myaddon.getSetting('escogido')+' ][/COLOR]',folder=False, isPlayable=False)   
    plugintools.add_item(title='[COLOR gray]-=========================-[/COLOR]',folder=False, isPlayable=False)   
    head='Se descarca lista de canale'
    pb  = xbmcgui.DialogProgressBG()    
    pb.create(head,'')        
    progreso=0
      
    for i in range(1,5):
        vpagina=i*10
        pagina=str(i)
        
        headers = '{"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="'+mac+'"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "'+token+'}'
    
        pn=vpagina-9  
        count=i*10;pn=pn;data=[]
        while pn <= count:
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
            page=portal+'portal.php?type=itv&action=get_ordered_list&genre='+ids+'&force_ch_link_check=&fav=0&sortby=number&hd=0&p='+str(pn)+'&JsHttpRequest=1-xml';source=requests.get(page, headers=headers).content.decode('ascii','ignore')
            data +=re.findall('("id":".*?","name":".*?".*?"ch_id":".*?")',str(source));pn +=1

        url=data
        total=len(data)
        c=1 
        for generos in url: 
            
            patron = plugintools.find_single_match(generos,'"id":".*?","name":"(.*?)".*?"ch_id":"(.*?)"')
            canal=patron[1]
            titulo=patron[0].replace('u021b','t').replace('\\','')

            tit=colorea(titulo)

            if  not('adult' in titulo.lower() and pr0n=="false"):                                    
            
                plugintools.add_item( action="reproduce_canal",extra=portal,url=canal,page=mac,plot=params.get("plot"),title = tit, thumbnail = params.get("thumbnail"), fanart= fanny,folder=False,  isPlayable = True )                                                 
                
                if guardar_favs=="true":
                    cmd='plugin://plugin.video.macvod/?action=reproduce_canal'+'&title='+urllib.quote(titulo,safe='')+'&url='+str(canal)+'&thumbnail=10'+'&plot='+urllib.quote(token,safe='')+'&extra='+urllib.quote(portal,safe='')+'&page='+urllib.quote(mac,safe='')
                    try:
                        if not canal in unicode(favs, 'utf-8'):
                            favourite(titulo,'10',cmd)
                    except:
                        pass

            progreso=str(int(round((c/total)*100)))                
            pb.update(int(progreso),heading=head+' '+progreso+'%',message='Se incarca canalul '+tit+' din pagina '+str(i)+' '+str(c)+'/'+str(total))    
            c=c+1
                

    pb.close()

def colorea(titulo):

    if  'romania' in titulo.lower() or 'rom' in titulo.lower() or 'EU -RO' in titulo or 'roumania' in titulo.lower():               
        color='darkorange'                                             
    else:
        if 'crime' in titulo.lower():
            color='springgreen'
        else:
            if 'axn' in titulo.lower()  or 'accion' in titulo.lower() or 'estrenos'  in titulo.lower() or 'historia'  in titulo.lower() or 'odisea'  in titulo.lower() or 'discovery'  in titulo.lower():
                    color='deeppink'
            else:        
                if 'adult' in titulo.lower() or 'xxx' in titulo.lower() or 'porn' in titulo.lower():
                    color='red'
                else:
                    color='mintcream'
    
    return '[COLOR '+color+']'+titulo+'[/COLOR]'

def reproduce_canal(params):
    s=''
    canal = params.get("url")
    portal = params.get("extra")
    mac = params.get("page")
    token = params.get("plot")
   
    headers =headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0","cookie": "mac="+mac+"; stb_lang=es; timezone=Europe/spain","Authorization": "Bearer "+token}
    url=portal+'portal.php?type=itv&action=create_link&cmd=http://localhost/ch/'+canal+'_&series=&forced_storage=undefined&disable_ad=0&download=0&JsHttpRequest=1-xml'

    try:       
        source=requests.get(url, headers=headers).text
        
        fuente=re.findall('"cmd":"ffmpeg (.*?)"',source )[0]
        fuente= fuente.replace("\\", "")
        
        url=fuente
    
        plugintools.play_resolved_url(url)
    except:
        xbmc.executebuiltin('XBMC.Notification(Eroare la redarea, ' +str(url)+ ', 8000)')            
     
    
def favourite(name,thumb,cmd):
    result = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Favourites.AddFavourite", "params": {"title":"%s", "type":"media", "path":"%s", "thumbnail":"%s"}, "id": 1}' % (name, cmd, thumb))

def linkdirecto(params):
    url = params.get("url")    
    plugintools.play_resolved_url(url)      


def carga_servidores(params):
    donde=str(params.get('extra'))
    head='Se incarca lista de canale '+str(donde)
    pb  = xbmcgui.DialogProgressBG()    
    pb.create(head,'')     
    
    fichero = xbmc.translatePath('special://home/userdata/addon_data/plugin.video.macvod/'+donde+'_servers.dat')

    try:
        f=open(fichero,'r')        
        servidores=f.readlines()
        lineas=len(servidores)
    except:
        f=open(fichero,'w+')        
        f.close()
        f=open(fichero,'r')        
        servidores=f.readlines()
        lineas=len(servidores)
        xbmc.executebuiltin('XBMC.Notification(Nu exista fisierul original , fichero: '+str(donde)+', 8000)')          
        xbmc.executebuiltin('Action(Back)')
    i=1
    lista_nombres=''
    lista_macs=''
    selectable=''
    #colors=['red','green','orange','blue','pink','chocolate','darkorange','magenta']
    for servidor in servidores:
        try:      
            
            mac=re.findall('#(00:.*?79:.*?........)', servidor)            
            portal=re.findall('portal"(.*?)"', servidor.lower())
            if portal:
                
                pb.update(int(round(i/lineas)*100),head,str(servidor))
                  
                #color=random.choice(colors)
                if i % 2 == 0:
                    color='white'
                else:
                    color='yellow'    

                if lista_nombres=='':
                    lista_nombres=portal[0]
                    lista_macs=mac[0]
                    selectable='[COLOR '+color+']'+str(i)+'::'+portal[0]+'#'+mac[0]+'[/COLOR]'
                else:
                    lista_nombres=lista_nombres+','+portal[0]
                    lista_macs=lista_macs+','+mac[0]
                    selectable=selectable+',[COLOR '+color+']'+str(i)+' :: '+portal[0]+' # '+mac[0]+'[/COLOR]'
                i+=1   
        except:
            xbmc.executebuiltin('XBMC.Notification([COLOR red]EROARE[/COLOR] la obtinerea datelor , SERVER: '+str(servidor)+', 8000)')               
                           
    f.close()
    pb.close()
    
    dialog = xbmcgui.Dialog()    
    select_one=selectable.split(',')
    retorno = dialog.select('Alege PORTAL+MAC', select_one)
    
    
    if str(retorno)=='-1':   
        xbmc.executebuiltin('Action(Back)')   
        #xbmc.executebuiltin('XBMC.Notification([COLOR red][/COLOR] obteniendo datos , SERVIDOR: '+str(server2)+', 8000)')                   
    else:
        l_n=lista_nombres.split(',')
        l_m=lista_macs.split(',')
        
        server2=str(l_n[retorno])
        mac2=str(l_m[retorno])
        
        myaddon.setSetting('mac2',mac2)
        myaddon.setSetting('portal2',server2)
        myaddon.setSetting('escogido','Fisier_LOCAL')
        myaddon.setSetting('ser',server2)
        
        # xbmc.executebuiltin('XBMC.Notification([COLOR red]Cancelo[/COLOR] Cancelado , No se ha escogido un servidor, 8000)')                   
    xbmc.executebuiltin('Content.refresh')    
    ver_canales(params)      



run()